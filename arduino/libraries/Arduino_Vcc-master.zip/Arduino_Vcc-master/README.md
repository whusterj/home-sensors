arduino_vcc
===========

Arduino library to read VCC supply level without external components
